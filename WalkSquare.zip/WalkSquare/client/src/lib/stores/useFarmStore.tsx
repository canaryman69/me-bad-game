import { create } from "zustand";

export interface TilledSoil {
  gridX: number; // Grid X position
  gridY: number; // Grid Y position
  x: number;     // World X position
  y: number;     // World Y position
  width: number;
  height: number;
  isWatered: boolean; // Track watered state
  hasSeed: boolean;   // Track if a seed is planted
  growthStage: number; // 0: no plant, 1: seed, 2: sprout, 3: mature
}

interface FarmState {
  // Game grid settings
  gridSize: number;
  gridCellSize: number;
  tilledSoil: TilledSoil[];
  
  // Actions
  tillSoil: (playerX: number, playerY: number) => void;
  waterSoil: (playerX: number, playerY: number) => boolean;
  plantSeed: (playerX: number, playerY: number) => boolean;
  harvestPlant: (playerX: number, playerY: number) => boolean;
  clearAllTilledSoil: () => void;
  
  // Query functions
  isTilled: (gridX: number, gridY: number) => boolean;
  isWatered: (gridX: number, gridY: number) => boolean;
  hasSeed: (gridX: number, gridY: number) => boolean;
  canPlantSeed: (gridX: number, gridY: number) => boolean;
  getSoilAtGridPosition: (gridX: number, gridY: number) => TilledSoil | undefined;
}

// The size of each grid cell (matches player character size)
const GRID_CELL_SIZE = 40;

export const useFarmStore = create<FarmState>((set, get) => ({
  // Initial state with empty array for tilled soil
  gridSize: GRID_CELL_SIZE,
  gridCellSize: GRID_CELL_SIZE,
  tilledSoil: [],
  
  // Helper to get soil at a specific grid position
  getSoilAtGridPosition: (gridX, gridY) => {
    return get().tilledSoil.find(soil => 
      soil.gridX === gridX && soil.gridY === gridY
    );
  },
  
  // Check if a grid cell is already tilled
  isTilled: (gridX, gridY) => {
    return get().tilledSoil.some(soil => 
      soil.gridX === gridX && soil.gridY === gridY
    );
  },
  
  // Check if a grid cell is watered
  isWatered: (gridX, gridY) => {
    const soil = get().getSoilAtGridPosition(gridX, gridY);
    return soil ? soil.isWatered : false;
  },
  
  // Check if a grid cell has a seed
  hasSeed: (gridX, gridY) => {
    const soil = get().getSoilAtGridPosition(gridX, gridY);
    return soil ? soil.hasSeed : false;
  },
  
  // Check if a seed can be planted at this grid position
  canPlantSeed: (gridX, gridY) => {
    const soil = get().getSoilAtGridPosition(gridX, gridY);
    return soil ? (soil.isWatered && !soil.hasSeed) : false;
  },
  
  // Add a new tilled soil patch at the specified grid position
  tillSoil: (playerX, playerY) => set((state) => {
    // Convert world coordinates to grid coordinates
    const gridX = Math.floor(playerX / state.gridCellSize);
    const gridY = Math.floor(playerY / state.gridCellSize);
    
    // Calculate the actual world position based on grid
    const soilX = gridX * state.gridCellSize;
    const soilY = gridY * state.gridCellSize;
    
    // Check if there's already tilled soil at this grid position
    if (state.tilledSoil.some(soil => soil.gridX === gridX && soil.gridY === gridY)) {
      return state; // No change if already tilled
    }
    
    console.log(`Tilling soil at grid position (${gridX}, ${gridY})`);
    
    // Add the new tilled soil patch
    return {
      tilledSoil: [
        ...state.tilledSoil,
        {
          gridX,
          gridY,
          x: soilX,
          y: soilY,
          width: state.gridCellSize,
          height: state.gridCellSize,
          isWatered: false, // Not watered initially
          hasSeed: false,   // No seed initially
          growthStage: 0    // No growth initially
        }
      ]
    };
  }),
  
  // Water soil at the specified grid position
  waterSoil: (playerX, playerY) => {
    // Convert world coordinates to grid coordinates
    const state = get();
    const gridX = Math.floor(playerX / state.gridCellSize);
    const gridY = Math.floor(playerY / state.gridCellSize);
    
    // Check if there's tilled soil at this position
    const soilIndex = state.tilledSoil.findIndex(
      soil => soil.gridX === gridX && soil.gridY === gridY
    );
    
    if (soilIndex === -1) {
      console.log('No tilled soil to water at this position');
      return false; // No tilled soil here to water
    }
    
    // Skip if already watered
    if (state.tilledSoil[soilIndex].isWatered) {
      console.log('Soil is already watered');
      return false;
    }
    
    console.log(`Watering soil at grid position (${gridX}, ${gridY})`);
    
    // Update the soil to be watered
    const updatedSoil = [...state.tilledSoil];
    updatedSoil[soilIndex] = {
      ...updatedSoil[soilIndex],
      isWatered: true
    };
    
    set({ tilledSoil: updatedSoil });
    return true; // Successfully watered
  },
  
  // Plant a seed in watered soil
  plantSeed: (playerX, playerY) => {
    // Convert world coordinates to grid coordinates
    const state = get();
    const gridX = Math.floor(playerX / state.gridCellSize);
    const gridY = Math.floor(playerY / state.gridCellSize);
    
    // Check if a seed can be planted here
    if (!state.canPlantSeed(gridX, gridY)) {
      const soil = state.getSoilAtGridPosition(gridX, gridY);
      
      if (!soil) {
        console.log('No tilled soil at this position');
        return false;
      } else if (!soil.isWatered) {
        console.log('Soil must be watered before planting');
        return false;
      } else if (soil.hasSeed) {
        console.log('A seed is already planted here');
        return false;
      }
      
      return false;
    }
    
    console.log(`Planting seed at grid position (${gridX}, ${gridY})`);
    
    // Find soil index
    const soilIndex = state.tilledSoil.findIndex(
      soil => soil.gridX === gridX && soil.gridY === gridY
    );
    
    // Plant the seed
    const updatedSoil = [...state.tilledSoil];
    updatedSoil[soilIndex] = {
      ...updatedSoil[soilIndex],
      hasSeed: true,
      growthStage: 1, // Seed stage
      plantedTime: Date.now(), // Track when the seed was planted
      lastWateredTime: Date.now() // Track when it was last watered
    };
    
    set({ tilledSoil: updatedSoil });

    // Start growth cycle
    const growthInterval = setInterval(() => {
      const currentState = get();
      const soil = currentState.getSoilAtGridPosition(gridX, gridY);
      
      if (soil && soil.hasSeed && soil.growthStage < 4) {
        const timeSincePlanted = Date.now() - soil.plantedTime;
        const newStage = Math.floor(timeSincePlanted / (1000 * 60)) + 1; // Grow every minute
        
        if (newStage <= 4 && newStage > soil.growthStage) {
          const updatedSoil = [...currentState.tilledSoil];
          const soilIndex = updatedSoil.findIndex(s => s.gridX === gridX && s.gridY === gridY);
          
          if (soilIndex !== -1) {
            updatedSoil[soilIndex] = {
              ...updatedSoil[soilIndex],
              growthStage: newStage
            };
            set({ tilledSoil: updatedSoil });
          }
        }
        
        if (newStage >= 4) {
          clearInterval(growthInterval);
        }
      } else {
        clearInterval(growthInterval);
      }
    }, 1000);
    
    return true; // Successfully planted
  },
  
  // Harvest a fully grown plant
  harvestPlant: (playerX, playerY) => {
    const state = get();
    const gridX = Math.floor(playerX / state.gridCellSize);
    const gridY = Math.floor(playerY / state.gridCellSize);
    
    // Find soil at position
    const soilIndex = state.tilledSoil.findIndex(
      soil => soil.gridX === gridX && soil.gridY === gridY
    );
    
    if (soilIndex === -1) return false;
    
    const soil = state.tilledSoil[soilIndex];
    
    // Check if plant is fully grown
    if (!soil.hasSeed || soil.growthStage < 4) {
      console.log('No fully grown plant to harvest');
      return false;
    }
    
    // Remove the plant and reset the soil
    const updatedSoil = [...state.tilledSoil];
    updatedSoil[soilIndex] = {
      ...updatedSoil[soilIndex],
      hasSeed: false,
      growthStage: 0,
      isWatered: false
    };
    
    set({ tilledSoil: updatedSoil });
    return true;
  },

  // Clear all tilled soil
  clearAllTilledSoil: () => set({ tilledSoil: [] }),
}));