import { create } from "zustand";
import { useFarmStore } from "./useFarmStore";

interface PlayerState {
  x: number;
  y: number;
  speed: number;
  direction: "idle" | "up" | "down" | "left" | "right";
  
  // Game area boundaries
  boundaries: {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
  };
  
  // Grid position
  gridX: number;
  gridY: number;
  
  // Actions
  moveUp: () => void;
  moveDown: () => void;
  moveLeft: () => void;
  moveRight: () => void;
  stopMoving: () => void;
  setBoundaries: (width: number, height: number) => void;
  setPosition: (x: number, y: number) => void;
  updatePosition: () => void;
  getGridPosition: () => { gridX: number, gridY: number };
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  // Initial position (center of screen)
  x: window.innerWidth / 2,
  y: window.innerHeight / 2,
  speed: 5, // pixels per update
  direction: "idle",
  gridX: 0,
  gridY: 0,
  
  // Initial boundaries (will be updated when game area is rendered)
  boundaries: {
    minX: 0,
    maxX: window.innerWidth,
    minY: 0,
    maxY: window.innerHeight,
  },
  
  // Movement actions
  moveUp: () => set({ direction: "up" }),
  moveDown: () => set({ direction: "down" }),
  moveLeft: () => set({ direction: "left" }),
  moveRight: () => set({ direction: "right" }),
  stopMoving: () => set({ direction: "idle" }),
  
  // Set game boundaries based on game area size
  setBoundaries: (width, height) => set((state) => ({
    boundaries: {
      minX: 40, // Account for character width (now 40px)
      maxX: width - 40,
      minY: 40, // Account for character height (now 40px)
      maxY: height - 40,
    }
  })),
  
  // Set position directly (used for initialization)
  setPosition: (x, y) => {
    // Get grid cell size (default to 40 if not loaded yet)
    const gridCellSize = 40;
    
    // Calculate grid position
    const gridX = Math.floor(x / gridCellSize);
    const gridY = Math.floor(y / gridCellSize);
    
    set({ x, y, gridX, gridY });
  },
  
  // Get current grid position
  getGridPosition: () => {
    const { x, y } = get();
    const gridCellSize = 40;
    
    return {
      gridX: Math.floor(x / gridCellSize),
      gridY: Math.floor(y / gridCellSize)
    };
  },
  
  // Update position based on current direction and speed
  updatePosition: () => set((state) => {
    let { x, y, speed, direction, boundaries } = state;
    const gridCellSize = 40;
    
    switch (direction) {
      case "up":
        y = Math.max(boundaries.minY, y - speed);
        break;
      case "down":
        y = Math.min(boundaries.maxY, y + speed);
        break;
      case "left":
        x = Math.max(boundaries.minX, x - speed);
        break;
      case "right":
        x = Math.min(boundaries.maxX, x + speed);
        break;
      default:
        // No movement for idle
        break;
    }
    
    // Update grid position when moving
    const gridX = Math.floor(x / gridCellSize);
    const gridY = Math.floor(y / gridCellSize);
    
    return { x, y, gridX, gridY };
  }),
}));
