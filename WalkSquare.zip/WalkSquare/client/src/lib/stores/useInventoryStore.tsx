import { create } from "zustand";
import { usePlayerStore } from "./usePlayerStore";
import { useFarmStore } from "./useFarmStore";
import { useAudio } from "./useAudio";

export interface InventoryItem {
  id: string;
  name: string;
  icon: string; // Path to item icon
  count: number;
  description?: string;
  slot: number;
}

interface InventoryState {
  items: InventoryItem[];
  maxSlots: number;
  selectedItemId: string | null;

  // Actions
  addItem: (item: InventoryItem) => void;
  removeItem: (itemId: string) => void;
  updateItemCount: (itemId: string, count: number) => void;
  clearInventory: () => void;
  hasItem: (itemId: string) => boolean;
  selectItem: (itemId: string) => void;
  useSelectedItem: () => void;
  getSelectedItem: () => InventoryItem | null;
}

export const useInventoryStore = create<InventoryState>((set, get) => ({
  // Initial inventory state
  items: [
    {
      id: "scythe",
      name: "Harvesting Scythe",
      icon: "🔪",
      count: 1,
      description: "Used to harvest fully grown plants",
      slot: 1
    },
    {
      id: "hoe",
      name: "Farming Hoe",
      icon: "🌾", 
      count: 1,
      description: "Used to till soil for planting",
      slot: 2
    },
    {
      id: "watering_can", 
      name: "Watering Can",
      icon: "💧",
      count: 1,
      description: "Waters plants to help them grow",
      slot: 3
    },
    {
      id: "seeds",
      name: "Seed Packet",
      icon: "🌱",
      count: 15,
      description: "Plant these to grow crops",
      slot: 4
    },
    {
      id: "potion",
      name: "Health Potion",
      icon: "🧪",
      count: 3,
      description: "Restores 25 health points",
      slot: 5
    },
    {
      id: "key",
      name: "Rusty Key",
      icon: "🔑",
      count: 1,
      description: "Opens a mysterious door",
      slot: 6
    },
    {
      id: "coin",
      name: "Gold Coin",
      icon: "🪙",
      count: 30,
      description: "Currency used for trading",
      slot: 7
    },
    {
      id: "harvested_plant",
      name: "Harvested Plant",
      icon: "🌿",
      count: 0,
      description: "A fully grown plant ready for use",
      slot: 8
    }
  ],
  maxSlots: 10,
  selectedItemId: null,

  // Add a new item to inventory or increment count if exists
  addItem: (item) => set((state) => {
    const existingItem = state.items.find(i => i.id === item.id);

    if (existingItem) {
      // Item exists, update count
      return {
        items: state.items.map(i => 
          i.id === item.id 
            ? { ...i, count: i.count + item.count }
            : i
        )
      };
    } else if (state.items.length < state.maxSlots) {
      // New item, add if slots available
      return {
        items: [...state.items, item]
      };
    }

    return state; // No change if inventory full
  }),

  // Remove an item from inventory
  removeItem: (itemId) => set((state) => ({
    items: state.items.filter(item => item.id !== itemId)
  })),

  // Update item count (remove if count becomes 0)
  updateItemCount: (itemId, count) => set((state) => {
    // Find the specific item instance to update
    const itemIndex = state.items.findIndex(item => item.id === itemId);
    if (itemIndex === -1) return state;

    const newItems = [...state.items];
    const newCount = Math.max(0, count);

    if (newCount === 0) {
      // Remove the item at the specific index
      newItems.splice(itemIndex, 1);
    } else {
      // Update the count at the specific index
      newItems[itemIndex] = { ...newItems[itemIndex], count: newCount };
    }

    return { items: newItems };
  }),

  // Clear all items from inventory
  clearInventory: () => set({ items: [] }),

  // Check if an item exists in inventory
  hasItem: (itemId) => get().items.some(item => item.id === itemId),

  // Select an item from inventory
  selectItem: (itemId) => set({ selectedItemId: itemId }),

  // Get the selected item
  getSelectedItem: () => {
    const { items, selectedItemId } = get();
    return items.find(item => item.id === selectedItemId) || null;
  },

  // Use the currently selected item
  useSelectedItem: () => {
    const { selectedItemId, items } = get();

    if (!selectedItemId) return; // No item selected

    const item = items.find(item => item.id === selectedItemId);
    if (!item) return; // Item not found

    console.log(`Using item: ${item.name}`);

    // Only for the potion which is consumed immediately
    if (item.id === "potion") {
      get().updateItemCount(selectedItemId, item.count - 1);
    }

    // Note: Seeds are consumed only if successfully planted, handled in the "seeds" case below

    // Get player position for items that need it
    const playerX = usePlayerStore.getState().x;
    const playerY = usePlayerStore.getState().y;

    // Try to play sound effects if available
    try {
      const audio = useAudio.getState();
      if (item.id === "hoe") {
        audio.playHit && audio.playHit();
      } else if (item.id === "seeds" || item.id === "watering_can") {
        audio.playSuccess && audio.playSuccess();
      }
    } catch (e) {
      console.log("Audio not available yet");
    }

    // Implement item use effects here as needed
    switch (item.id) {
      case "scythe":
        console.log("Attempting to harvest plant...");
        {
          const wasHarvested = useFarmStore.getState().harvestPlant(playerX, playerY);
          if (wasHarvested) {
            // Add harvested plant to inventory
            const harvestedPlantItem = get().items.find(item => item.id === "harvested_plant");
            if (harvestedPlantItem) {
              get().updateItemCount("harvested_plant", harvestedPlantItem.count + 1);
            }

            try {
              const audio = useAudio.getState();
              if (audio.successSound) {
                audio.successSound.volume = 0.5;
                audio.successSound.currentTime = 0;
                audio.successSound.play();
              }
            } catch (e) {
              console.log("Success sound not available yet");
            }
          }
        }
        break;
      case "hoe":
        console.log("Tilling soil...");
        {
          // Create tilled soil at player's position using grid-based system
          const gridPosition = usePlayerStore.getState().getGridPosition();
          console.log(`Using hoe at grid position (${gridPosition.gridX}, ${gridPosition.gridY})`);
          useFarmStore.getState().tillSoil(playerX, playerY);
        }
        break;
      case "watering_can":
        console.log("Watering soil...");
        {
          // Get grid position for watering
          const playerGridPosition = usePlayerStore.getState().getGridPosition();
          console.log(`Using watering can at grid position (${playerGridPosition.gridX}, ${playerGridPosition.gridY})`);

          // Try to water soil at current position
          const wasWatered = useFarmStore.getState().waterSoil(playerX, playerY);

          // Play success sound if successfully watered
          if (wasWatered) {
            try {
              const audio = useAudio.getState();
              if (audio.successSound) {
                audio.successSound.volume = 0.5;
                audio.successSound.currentTime = 0;
                audio.successSound.play();
              }
            } catch (e) {
              console.log("Success sound not available yet");
            }
          }
        }
        break;
      case "seeds":
        console.log("Planting a seed...");
        {
          // Get grid position for planting
          const playerGridPosition = usePlayerStore.getState().getGridPosition();
          console.log(`Trying to plant a seed at grid position (${playerGridPosition.gridX}, ${playerGridPosition.gridY})`);

          // Try to plant a seed at the current position
          const wasPlanted = useFarmStore.getState().plantSeed(playerX, playerY);

          // Only reduce seed count if it was actually planted
          if (wasPlanted) {
            // Play success sound
            try {
              const audio = useAudio.getState();
              if (audio.successSound) {
                audio.successSound.volume = 0.5;
                audio.successSound.currentTime = 0;
                audio.successSound.play();
              }
            } catch (e) {
              console.log("Success sound not available yet");
            }

            // Reduce the seed count (consumable item)
            get().updateItemCount(item.id, item.count - 1);
          }
        }
        break;
      case "potion":
        {
          const farmStore = useFarmStore.getState();
          const gridX = Math.floor(playerX / 40);
          const gridY = Math.floor(playerY / 40);
          const soil = farmStore.getSoilAtGridPosition(gridX, gridY);

          if (soil && soil.hasSeed && soil.growthStage < 4) {
            const updatedSoil = [...farmStore.tilledSoil];
            const soilIndex = updatedSoil.findIndex(
              s => s.gridX === gridX && s.gridY === gridY
            );

            updatedSoil[soilIndex] = {
              ...updatedSoil[soilIndex],
              growthStage: 4 // Set to fully grown
            };
            
            farmStore.setState({ tilledSoil: updatedSoil });
            get().updateItemCount(selectedItemId, item.count - 1);

            try {
              const audio = useAudio.getState();
              if (audio.successSound) {
                audio.successSound.volume = 0.5;
                audio.successSound.currentTime = 0;
                audio.successSound.play();
              }
            } catch (e) {
              console.log("Success sound not available yet");
            }
          } else if (soil?.growthStage === 4) {
            console.log("Plant is already fully grown");
          } else {
            console.log("No plant found here to use potion on");
          }
        }
        break;
        break;
      case "key":
        console.log("Trying to unlock something...");
        break;
      case "coin":
        console.log("Can't use coins directly, need to trade");
        break;
    }
  }
}));