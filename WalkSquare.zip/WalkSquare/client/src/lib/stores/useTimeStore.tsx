import { create } from "zustand";

// Game time configuration
const SECONDS_PER_GAME_HOUR = 30; // 30 real seconds = 1 game hour
const HOURS_PER_DAY = 24;
const MINUTES_PER_HOUR = 60;
const MS_PER_GAME_MINUTE = (SECONDS_PER_GAME_HOUR * 1000) / MINUTES_PER_HOUR; // Milliseconds per game minute

// A day lasts 12 minutes in real time (30 seconds × 24 hours = 720 seconds = 12 minutes)

// Days of the week and seasons
const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const SEASONS = ["Spring", "Summer", "Fall", "Winter"];

interface TimeState {
  // Current time values
  hour: number;
  minute: number;
  day: number;
  season: number;
  year: number;
  
  // Formatted values
  formattedTime: string;
  dayOfWeek: string;
  seasonName: string;

  // Time control
  isPaused: boolean;
  timeScale: number;

  // Actions
  initializeTime: () => void;
  updateTime: () => void;
  togglePause: () => void;
  setTimeScale: (scale: number) => void;
}

export const useTimeStore = create<TimeState>((set, get) => ({
  // Initialize with 6:00 AM on day 1 of spring, year 1
  hour: 6,
  minute: 0,
  day: 1,
  season: 0,
  year: 1,
  
  formattedTime: "6:00 AM",
  dayOfWeek: DAYS_OF_WEEK[1], // Start on Monday
  seasonName: SEASONS[0],
  
  isPaused: false,
  timeScale: 1,
  
  // Initialize the time system and start the clock
  initializeTime: () => {
    // Start the time update loop if not already running
    const timeLoop = setInterval(() => {
      if (!get().isPaused) {
        get().updateTime();
      }
    }, MS_PER_GAME_MINUTE); // Update every game minute
    
    // Return cleanup function if needed in the future
    return () => clearInterval(timeLoop);
  },
  
  // Update the game time by one minute
  updateTime: () => set(state => {
    let newMinute = state.minute + 1;
    let newHour = state.hour;
    let newDay = state.day;
    let newSeason = state.season;
    let newYear = state.year;
    
    // Roll over minutes to hours
    if (newMinute >= MINUTES_PER_HOUR) {
      newMinute = 0;
      newHour++;
      
      // Roll over hours to days
      if (newHour >= HOURS_PER_DAY) {
        newHour = 0;
        newDay++;
        
        // Roll over days to seasons (assuming 28 days per season)
        if (newDay > 28) {
          newDay = 1;
          newSeason++;
          
          // Roll over seasons to years
          if (newSeason >= SEASONS.length) {
            newSeason = 0;
            newYear++;
          }
        }
      }
    }
    
    // Calculate day of week (1-based day)
    const dayIndex = (newDay - 1) % 7;
    const newDayOfWeek = DAYS_OF_WEEK[dayIndex];
    
    // Format time as "HH:MM AM/PM"
    const period = newHour >= 12 ? "PM" : "AM";
    const displayHour = newHour % 12 === 0 ? 12 : newHour % 12;
    const displayMinute = newMinute.toString().padStart(2, '0');
    const newFormattedTime = `${displayHour}:${displayMinute} ${period}`;
    
    return {
      minute: newMinute,
      hour: newHour,
      day: newDay,
      season: newSeason,
      year: newYear,
      dayOfWeek: newDayOfWeek,
      seasonName: SEASONS[newSeason],
      formattedTime: newFormattedTime
    };
  }),
  
  // Toggle pause state
  togglePause: () => set(state => ({ isPaused: !state.isPaused })),
  
  // Set time scale (for speed control)
  setTimeScale: (scale) => set({ timeScale: scale })
}));