import React, { useEffect } from "react";
import { useTimeStore } from "@/lib/stores/useTimeStore";

interface DigitalClockProps {
  className?: string;
}

export const DigitalClock: React.FC<DigitalClockProps> = ({ className = "" }) => {
  const { 
    formattedTime, 
    dayOfWeek, 
    day, 
    seasonName, 
    year,
    initializeTime 
  } = useTimeStore();
  
  // Initialize the clock on component mount
  useEffect(() => {
    const cleanup = initializeTime();
    return cleanup;
  }, [initializeTime]);
  
  return (
    <div className={`digital-clock bg-white bg-opacity-80 p-2 rounded-md shadow-md ${className}`}>
      <div className="text-xl font-bold">{formattedTime}</div>
      <div className="text-sm">{dayOfWeek}, {seasonName} {day}</div>
      <div className="text-xs">Year {year}</div>
    </div>
  );
};