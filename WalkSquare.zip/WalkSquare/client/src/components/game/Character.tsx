import React, { useRef, useEffect } from "react";
import { usePlayerStore } from "@/lib/stores/usePlayerStore";
import { useFarmStore } from "@/lib/stores/useFarmStore";

interface CharacterProps {
  width?: number;
  height?: number;
}

export const Character: React.FC<CharacterProps> = ({ 
  width = 40, // Match grid cell size
  height = 40 // Match grid cell size
}) => {
  const { x, y, direction } = usePlayerStore();
  const gridCellSize = useFarmStore(state => state.gridCellSize);
  const characterRef = useRef<HTMLDivElement>(null);

  // Apply any animation or direction-based transformations
  useEffect(() => {
    if (characterRef.current) {
      // Add any direction-based CSS classes or transformations
      const element = characterRef.current;
      
      // Reset all direction-specific classes
      element.classList.remove("character-left", "character-right", "character-up", "character-down");
      
      // Add class based on current direction
      if (direction !== "idle") {
        element.classList.add(`character-${direction}`);
      }
    }
  }, [direction]);

  return (
    <div
      ref={characterRef}
      className="character absolute rounded-sm"
      style={{
        width: `${width}px`,
        height: `${height}px`,
        position: "absolute",
        left: `${x}px`,
        top: `${y}px`,
        transform: `translate(-50%, -50%)`, // Center on position
        backgroundImage: `url(/src/assets/character.svg)`,
        backgroundSize: "contain",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center",
        backgroundColor: "rgba(255, 100, 100, 0.2)", // Light red marker for debugging
        border: "2px solid rgba(255, 255, 255, 0.4)",
        zIndex: 10
      }}
    />
  );
};
