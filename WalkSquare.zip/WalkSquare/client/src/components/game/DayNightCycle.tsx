
import React from 'react';
import { useTimeStore } from '@/lib/stores/useTimeStore';

export const DayNightCycle: React.FC = () => {
  const { hour } = useTimeStore();
  
  // Calculate opacity based on time of day
  const getOverlayOpacity = () => {
    if (hour >= 22.5 || hour <= 4) { // Full night (10:30 PM - 4 AM)
      return 0.7;
    } else if (hour > 4 && hour < 6) { // Dawn
      return 0.7 - ((hour - 4) * 0.35);
    } else if (hour >= 6 && hour < 19) { // Day
      return 0;
    } else if (hour >= 19 && hour < 22.5) { // Gradual dusk (7 PM - 10:30 PM)
      return (hour - 19) * 0.2; // Gradual increase over 3.5 hours
    }
    return 0;
  };

  return (
    <div 
      className="fixed inset-0 pointer-events-none z-10 transition-opacity duration-1000"
      style={{
        backgroundColor: '#001',
        opacity: getOverlayOpacity()
      }}
    />
  );
};
