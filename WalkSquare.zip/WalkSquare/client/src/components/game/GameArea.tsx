import React, { useEffect, useRef, useState } from "react";
import { Character } from "./Character";
import { ControlButton } from "./ControlButton";
import { InventorySidebar } from "./InventorySidebar";
import { UseItemButton } from "./UseItemButton";
import { TilledSoil } from "./TilledSoil";
import { GridOverlay } from "./GridOverlay";
import { DigitalClock } from "./DigitalClock";
import { DayNightCycle } from "./DayNightCycle";
import { usePlayerStore } from "@/lib/stores/usePlayerStore";

// Define the world size as much larger than the viewport
const WORLD_WIDTH = 2000;
const WORLD_HEIGHT = 2000;

export const GameArea: React.FC = () => {
  const viewportRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number>();
  
  // Get access to player state and actions
  const {
    x, 
    y,
    moveUp,
    moveDown,
    moveLeft,
    moveRight,
    stopMoving,
    updatePosition,
    setBoundaries,
    setPosition,
  } = usePlayerStore();

  // Calculate camera position (centered on player)
  const [cameraX, setCameraX] = useState(0);
  const [cameraY, setCameraY] = useState(0);

  // Update camera position to follow player
  useEffect(() => {
    if (viewportRef.current) {
      const viewportWidth = viewportRef.current.clientWidth;
      const viewportHeight = viewportRef.current.clientHeight;
      
      // Center camera on player, but don't go beyond world boundaries
      let newCameraX = Math.max(0, Math.min(x - viewportWidth / 2, WORLD_WIDTH - viewportWidth));
      let newCameraY = Math.max(0, Math.min(y - viewportHeight / 2, WORLD_HEIGHT - viewportHeight));
      
      setCameraX(newCameraX);
      setCameraY(newCameraY);
    }
  }, [x, y]);

  // Set up game loop for continuous movement
  useEffect(() => {
    const animate = () => {
      updatePosition();
      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);

    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [updatePosition]);

  // Set up boundaries based on world size
  useEffect(() => {
    // World boundaries are now fixed to the world size
    setBoundaries(WORLD_WIDTH, WORLD_HEIGHT);
    
    // Initialize player position to center of world
    setPosition(WORLD_WIDTH / 2, WORLD_HEIGHT / 2);
    
  }, [setBoundaries, setPosition]);

  return (
    <div className="w-full h-full flex">
      {/* Inventory Sidebar */}
      <InventorySidebar />
      
      {/* Game Viewport */}
      <div 
        ref={viewportRef}
        className="flex-grow h-full relative overflow-hidden"
      >
        {/* Scrollable World Area */}
        <div
          ref={worldRef}
          className="absolute bg-green-500"
          style={{
            width: WORLD_WIDTH,
            height: WORLD_HEIGHT,
            transform: `translate(${-cameraX}px, ${-cameraY}px)`,
          }}
        >
          {/* Grid overlay for visual reference */}
          <GridOverlay width={WORLD_WIDTH} height={WORLD_HEIGHT} />
          
          {/* Tilled soil patches (rendered before character) */}
          <TilledSoil />
          
          {/* Character (positioned in world coordinates) */}
          <Character />
        </div>

        <DayNightCycle />
        {/* Digital Clock in top right corner */}
        <div className="absolute top-4 right-4 z-20">
          <DigitalClock />
        </div>
        
        {/* Fixed UI Elements (control buttons) */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-5 z-10">
          {/* Directional Controls - using direct positioning for more control */}
          <div className="flex flex-col items-center">
            {/* Top row - only up arrow */}
            <div className="mb-1.5 flex justify-center">
              <ControlButton
                direction="up"
                onPressStart={moveUp}
                onPressEnd={stopMoving}
              />
            </div>
            
            {/* Bottom row - left, down, right arrows with increased spacing */}
            <div className="flex items-center">
              <div className="mr-4">
                <ControlButton
                  direction="left"
                  onPressStart={moveLeft}
                  onPressEnd={stopMoving}
                />
              </div>
              <div>
                <ControlButton
                  direction="down"
                  onPressStart={moveDown}
                  onPressEnd={stopMoving}
                />
              </div>
              <div className="ml-4">
                <ControlButton
                  direction="right"
                  onPressStart={moveRight}
                  onPressEnd={stopMoving}
                />
              </div>
            </div>
          </div>
          
          {/* Use Item Button - positioned to the right of the arrow keys */}
          <div className="ml-2">
            <UseItemButton />
          </div>
        </div>
      </div>
    </div>
  );
};
