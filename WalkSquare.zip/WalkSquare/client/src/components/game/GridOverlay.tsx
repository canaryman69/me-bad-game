import React from "react";
import { useFarmStore } from "@/lib/stores/useFarmStore";

interface GridOverlayProps {
  width: number;
  height: number;
}

export const GridOverlay: React.FC<GridOverlayProps> = ({ width, height }) => {
  const gridCellSize = useFarmStore((state) => state.gridCellSize);
  
  // Calculate number of horizontal and vertical grid lines
  const horizontalLines = Math.floor(height / gridCellSize);
  const verticalLines = Math.floor(width / gridCellSize);
  
  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 3 }}>
      {/* Horizontal grid lines */}
      {Array.from({ length: horizontalLines }).map((_, index) => (
        <div
          key={`h-${index}`}
          className="absolute w-full border-t border-white/10"
          style={{ top: `${index * gridCellSize}px` }}
        />
      ))}
      
      {/* Vertical grid lines */}
      {Array.from({ length: verticalLines }).map((_, index) => (
        <div
          key={`v-${index}`}
          className="absolute h-full border-l border-white/10"
          style={{ left: `${index * gridCellSize}px` }}
        />
      ))}
    </div>
  );
};