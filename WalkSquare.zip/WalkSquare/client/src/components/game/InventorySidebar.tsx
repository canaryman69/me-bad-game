import React from "react";
import { useInventoryStore, InventoryItem } from "@/lib/stores/useInventoryStore";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

export const InventorySidebar: React.FC = () => {
  const { items, maxSlots, selectedItemId } = useInventoryStore();
  
  return (
    <div className="h-full w-12 bg-gray-800 text-white shadow-lg flex flex-col">
      <ScrollArea className="flex-grow flex flex-col justify-end">
        <div className="py-2 h-full flex flex-col justify-end">
          <div className="flex flex-col items-center gap-4">
            {Array.from({ length: maxSlots }).map((_, index) => {
              const slotNumber = maxSlots - index;
              const item = items.find(item => item.slot === slotNumber);
              
              return (
                <div key={`slot-${slotNumber}`} className="relative">
                  <span className="absolute -top-3 -left-1 flex items-center justify-center w-4 h-4 rounded-full bg-gray-700 text-xs text-gray-400">{index + 1}</span>
                  {item ? (
                    <InventoryItemIcon 
                      item={item} 
                      isSelected={item.id === selectedItemId}
                    />
                  ) : (
                    <EmptySlot slotNumber={index + 1} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

interface InventoryItemIconProps {
  item: InventoryItem;
  isSelected: boolean;
}

const InventoryItemIcon: React.FC<InventoryItemIconProps> = ({ item, isSelected }) => {
  const { selectItem } = useInventoryStore();
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className={cn(
              "w-8 h-8 bg-gray-700 rounded-md flex items-center justify-center text-xl relative hover:bg-gray-600 cursor-pointer",
              isSelected && "ring-2 ring-yellow-400 bg-gray-600"
            )}
            onClick={() => selectItem(item.id)}
          >
            {item.icon}
            {item.count > 1 && (
              <div className="absolute -bottom-1 -right-1 bg-gray-900 rounded-full px-1 text-xs text-white">
                {item.count}
              </div>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent side="right" className="bg-gray-800 text-white border-gray-700">
          <div className="font-medium">{item.name}</div>
          {item.description && (
            <div className="text-xs text-gray-300">{item.description}</div>
          )}
          {isSelected && (
            <div className="text-xs text-yellow-400 mt-1">Selected</div>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

interface EmptySlotProps {
  slotNumber: number;
}

const EmptySlot: React.FC<EmptySlotProps> = ({ slotNumber }) => {
  return (
    <div className="w-8 h-8 bg-gray-700 bg-opacity-30 rounded-md border border-gray-600 border-dashed relative">
      <span className="absolute -top-3 -left-1 flex items-center justify-center w-4 h-4 rounded-full bg-gray-700 text-xs text-gray-400">{slotNumber}</span>
    </div>
  );
};