import React from "react";
import { useFarmStore, TilledSoil as TilledSoilType } from "@/lib/stores/useFarmStore";

export const TilledSoil: React.FC = () => {
  // Get the tilled soil from the store
  const tilledSoil = useFarmStore((state) => state.tilledSoil);
  
  return (
    <>
      {/* Render grid-aligned tilled soil patches */}
      {tilledSoil.map((soil) => (
        <div
          key={`${soil.gridX}-${soil.gridY}`}
          className={`absolute rounded-sm ${
            soil.isWatered 
              ? "bg-amber-950 border border-amber-900"  // Darker when watered
              : "bg-amber-900 border border-amber-800"  // Regular tilled soil color
          }`}
          style={{
            left: `${soil.x}px`,
            top: `${soil.y}px`,
            width: `${soil.width}px`,
            height: `${soil.height}px`,
            zIndex: 5, // Below character (10) but above background (1)
            transition: "background-color 0.3s ease",
          }}
        >
          {/* Optional water droplet indicators for watered soil */}
          {soil.isWatered && (
            <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 opacity-60">
              <div className="flex items-center justify-center">
                <div className="w-2 h-2 bg-blue-700 rounded-full opacity-30"></div>
              </div>
              <div className="flex items-center justify-center">
                <div className="w-1 h-1 bg-blue-500 rounded-full opacity-20"></div>
              </div>
              <div className="flex items-center justify-center">
                <div className="w-1 h-1 bg-blue-500 rounded-full opacity-20"></div>
              </div>
              <div className="flex items-center justify-center">
                <div className="w-2 h-2 bg-blue-700 rounded-full opacity-30"></div>
              </div>
            </div>
          )}
          
          {/* Plant growth indicators */}
          {soil.hasSeed && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                {/* Growth stage visuals */}
                {soil.growthStage === 1 && (
                  <div className="w-4 h-4 bg-yellow-700 rounded-full border border-yellow-800 shadow-sm">
                    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-2 bg-green-600 rounded-t-full"></div>
                  </div>
                )}
                {soil.growthStage === 2 && (
                  <div className="relative">
                    <div className="w-3 h-6 bg-green-600">
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-4 h-2 bg-green-500 rounded-full"></div>
                    </div>
                  </div>
                )}
                {soil.growthStage === 3 && (
                  <div className="relative">
                    <div className="w-6 h-8 bg-green-600">
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-6 h-3 bg-green-500 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-4 h-2 bg-yellow-300 rounded-full"></div>
                    </div>
                  </div>
                )}
                {soil.growthStage === 4 && (
                  <div className="relative">
                    <div className="w-8 h-10 bg-green-600">
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-8 h-4 bg-green-500 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-6 h-4 bg-yellow-400 rounded-full"></div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ))}
    </>
  );
};