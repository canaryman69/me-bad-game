import React from "react";
import { Button } from "@/components/ui/button";
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";

interface ControlButtonProps {
  direction: "up" | "down" | "left" | "right";
  onPressStart: () => void;
  onPressEnd: () => void;
}

export const ControlButton: React.FC<ControlButtonProps> = ({
  direction,
  onPressStart,
  onPressEnd,
}) => {
  // Map direction to icon
  const getIcon = () => {
    switch (direction) {
      case "up": return <ChevronUp size={24} />;
      case "down": return <ChevronDown size={24} />;
      case "left": return <ChevronLeft size={24} />;
      case "right": return <ChevronRight size={24} />;
    }
  };
  
  // Handle touch events for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault(); // Prevent scrolling
    onPressStart();
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    onPressEnd();
  };

  // Handle mouse events for desktop
  const handleMouseDown = () => onPressStart();
  const handleMouseUp = () => onPressEnd();
  const handleMouseLeave = () => onPressEnd();

  return (
    <Button
      variant="secondary"
      size="lg"
      className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 shadow-lg"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
      aria-label={`Move ${direction}`}
    >
      {getIcon()}
    </Button>
  );
};
