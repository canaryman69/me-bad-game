import React, { useState, useEffect, useMemo } from "react";
import { useInventoryStore } from "@/lib/stores/useInventoryStore";
import { usePlayerStore } from "@/lib/stores/usePlayerStore";
import { useFarmStore } from "@/lib/stores/useFarmStore";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface UseItemButtonProps {
  className?: string;
}

export const UseItemButton: React.FC<UseItemButtonProps> = ({ className }) => {
  const { getSelectedItem, useSelectedItem } = useInventoryStore();
  const selectedItem = getSelectedItem();
  
  // State for tooltip message
  const [tooltipMessage, setTooltipMessage] = useState<string>("");
  const [canUseItem, setCanUseItem] = useState<boolean>(true);
  
  // Track player grid position for UI updates
  const playerGridX = usePlayerStore(state => state.gridX);
  const playerGridY = usePlayerStore(state => state.gridY);
  
  // Track farm state for seed planting check
  const isTilled = useFarmStore(state => state.isTilled(playerGridX, playerGridY));
  const isWatered = useFarmStore(state => state.isWatered(playerGridX, playerGridY));
  const hasSeed = useFarmStore(state => state.hasSeed(playerGridX, playerGridY));
  
  // Update UI based on selected item and position
  useEffect(() => {
    // Check if special conditions prevent item use
    if (!selectedItem) {
      setTooltipMessage("Select an item from your inventory first");
      setCanUseItem(false);
      return;
    }
    
    // Default assumptions
    setTooltipMessage(`Use ${selectedItem.name}`);
    setCanUseItem(true);
    
    // For seeds, check if they can be planted at the current position
    if (selectedItem.id === "seeds") {
      // Check conditions for planting
      if (!isTilled) {
        setTooltipMessage("Seeds need tilled soil");
        setCanUseItem(true); // Still allow trying, will show error in console
      } else if (!isWatered) {
        setTooltipMessage("Seeds need watered soil");
        setCanUseItem(true); // Still allow trying, will show error in console
      } else if (hasSeed) {
        setTooltipMessage("A seed is already planted here");
        setCanUseItem(false); // Disable button, can't plant here
      } else {
        setTooltipMessage("Plant seed here");
        setCanUseItem(true);
      }
    }
  }, [selectedItem, playerGridX, playerGridY, isTilled, isWatered, hasSeed]);
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            className={`w-16 h-16 text-lg ${className}`}
            variant={selectedItem && canUseItem ? "default" : "secondary"}
            onClick={useSelectedItem}
            disabled={!selectedItem || !canUseItem}
          >
            {selectedItem ? selectedItem.icon : "🧰"}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top" className="bg-gray-800 text-white border-gray-700">
          {tooltipMessage}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};