import React, { useEffect } from "react";
import { GameArea } from "@/components/game/GameArea";
import "@fontsource/inter";

function App() {
  // Set up the full-screen layout
  useEffect(() => {
    // Ensure body and html have full height
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.overflow = "hidden";
    document.documentElement.style.height = "100%";
    document.body.style.height = "100%";
  }, []);

  return (
    <div className="w-screen h-screen overflow-hidden">
      <GameArea />
    </div>
  );
}

export default App;
